<template>
  <div class="row">
    <div class="col-xs-12">
      <footer>
        <p>Tüm Hakları Saklıdır | videosinif.com</p>
      </footer>
    </div>
  </div>
</template>

<script></script>
