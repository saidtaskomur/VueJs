<template>
  <div class="col-xs-12 col-sm-6">
    <p>Sunucu Bilgisi güncel değil!!</p>
  </div>
</template>

<script></script>

<style scoped>

  div{
    border: 2px solid #fbbd08;
  }


</style>
